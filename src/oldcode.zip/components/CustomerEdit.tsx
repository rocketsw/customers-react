import { useState } from 'react';
import './CustomerEdit.css'
import { CustomerType, CustomerTypeEditProps } from './Customers'

export const CustomerEdit = ({ customer }: CustomerTypeEditProps) => {
    console.log('in CustomerEdit', customer )
    const [customerToEdit, setCustomerToEdit] = useState<CustomerType>(customer);
    const [textarea, setTextarea] = useState("");

    setTimeout(() => {
    if( !customerToEdit || !customerToEdit.id  || customerToEdit.id !== customer.id) {
        setCustomerToEdit( customer )
        console.log('called setCustomerToEdit() with', customer )
     } }, 500 )
    function submit() {
        console.log("submitting customer id :" + customerToEdit.id);
        
        let missingEntry = false;  //checkRequired();
        if (!missingEntry) {
            let id = customerToEdit.id
            let first = customerToEdit.first
            let last = customerToEdit.last
            let street = customerToEdit.street
            let city = customerToEdit.city
            let state = customerToEdit.state
            let zip = customerToEdit.zip
            let phone = customerToEdit.phone
            let customerParamStr = "id=" + id + "&first=" + first + "&last=" + last + "&street=" + street + "&city=" + city + "&state=" + state + "&zip=" + zip + "&phone=" + phone;
            console.log(customerParamStr)
            // url will be something like http://localhost:5000/add?arg1=2&arg2=3
            let url = "http://localhost:3000/updateCustomer?" + customerParamStr;
            let xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState === 4 && this.status === 200) {
                    callBackFct(this);
                }
            }
            xhttp.open("GET", url, true);
            xhttp.send();
        }
        
    }

    function callBackFct(xhttp) {
        setTextarea( xhttp.responseText )
    }

    const onChangeInput = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        console.log("name: ", name, " value:", value )
        setCustomerToEdit({ ...customerToEdit, [name]: value });
      };
      
      const handleChange = (event) => {
        setTextarea(event.target.value)
      }  

    return (
        <>
            <h1>Edit Customer</h1>
            <div className="wrapper">
                <div className="container">
                    <div>
                        <div className="data-div">
                            <label htmlFor="firstname">First Name:</label>
                            <input type="text" id="first" name="first" defaultValue={customerToEdit.first} onChange={onChangeInput} placeholder="Enter your first name" />
                        </div>
                        <div className="data-div">
                            <label htmlFor="street">Street Address:</label>
                            <input type="text" id="street" name="street" defaultValue={customerToEdit.street} onChange={onChangeInput} placeholder="Enter your street address"/>
                        </div>
                        <div className="data-div">
                            <label htmlFor="city">City:</label>
                            <input type="text" id="city" name="city" defaultValue={customerToEdit.city} onChange={onChangeInput} placeholder="Enter your city" />
                        </div>
                        <div className="data-div">
                            <label htmlFor="zipcode">Zip Code:</label>
                            <input type="text" id="zip" name="zip" defaultValue={customerToEdit.zip} onChange={onChangeInput} placeholder="Enter your Zip Code" />
                        </div>
                        <div className="data-div">
                            <label htmlFor="phonenumber">Phone:</label>
                            <input type="text" id="phone" name="phone" defaultValue={customerToEdit.phone} onChange={onChangeInput} placeholder="Enter your phone number" />
                        </div>
                    </div>
                    <div>
                        <div className="data-div">
                            <label htmlFor="lastname">Last Name:</label>
                            <input type="text" id="last" name="last" defaultValue={customerToEdit.last} onChange={onChangeInput} placeholder="Enter your last name" />
                        </div>
                        <div className="data-div">
                            <label className="noshow" ></label>
                            <input className="noshow" />
                        </div>
                        <div className="data-div">
                            <label htmlFor="state">State:</label>
                            <input type="text" id="state" name="state" defaultValue={customerToEdit.state} onChange={onChangeInput} placeholder="Enter your State"/>
                        </div>
                    </div>
                </div>
            </div>

            <div className="rowcenter">
                <button className="btn" type="button" onClick={submit}>Submit</button>
            </div>
            <div className="rowcenter">
                <div><textarea rows={4} cols={70} id="answer" defaultValue={textarea} onChange={handleChange}></textarea></div>
            </div>
        </>
    )
}
