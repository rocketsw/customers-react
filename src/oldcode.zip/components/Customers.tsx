import './Customers.css'
import { useEffect, useState, useRef } from 'react'

export type CustomerType = {
    id: number;
    first: string;
    last: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
}

export type CustomerTypeEditProps = {
    customer: CustomerType;
}

export const Customers = ({ setCustomer }) => {
    console.log("in Customer")
    const [customers, setCustomers] = useState<CustomerType[]>([]);


    let loadCustomersOld = (httpResponse) => {
        let jsonObj: CustomerType[] = JSON.parse(httpResponse.responseText);
        setCustomers(jsonObj)
    }


    let loadCustomers = (json) => {
        console.log('in loadCustomers')
        setCustomers(json)
    }

    const onSuccess = useRef(loadCustomers);
    onSuccess.current = loadCustomers
/*
    useEffect(() => {
        let url = "http://localhost:3000/customers"
        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                onSuccess.current(this);
            }
        };
        xhttp.open("GET", url, true);
        xhttp.send();
    }, [])
*/
    useEffect(() => {
        let url = "http://localhost:3000/customers"
        fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw new Error("Network response was not OK");
                }
                /*
                const contentType = response.headers.get("content-type");
                if (!contentType || !contentType.includes("application/json")) {
                    throw new TypeError("Error, response was not JSON!");
                }
                */
                return response.json();
            })
            .then((result) => {  // result is an object
                console.log("Success:", result);
                onSuccess.current(result);
            })
            .catch((error) => {
                console.error("There has been a problem with the fetch operation:", error);
            });
    },[])

    function edit() {
        console.log("edit()");
        let radios = document.getElementsByName('custid');
        let index = -1;
        for (let i = 0, length = radios.length; i < length; i++) {
            let radio = radios[i] as HTMLInputElement;
            if (radio.checked) {
                index = i;  //radio.value;
                break;
            }
        }
        if (index > -1) {
            //alert( "editing customer " + id + " from row " + i + " " + customers[index]["last"]);
            editCustomer(index);
        }
        else {
            alert("select a row to edit");
        }
    }

    function editCustomer(index: number): CustomerType {
        console.log("index = " + index);
        if (index >= 0) {
            console.log('calling setCustomer() with ', customers[index])
            setCustomer(customers[index])
        }
        else {
            alert("index out of range");
        }
        return customers[index]
    }

    return (
        <>
            <div className="list-container">
                <h2>Customers</h2>
                <div className="list-row" id="customers">
                    <table>
                        <thead>
                            <tr>
                                <th>Select</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Street</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Zip</th>
                                <th>Phone</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                customers.map((customer) => (
                                    <tr key={customer.id}>
                                        <td><input type="radio" name="custid" value={customer.id} /></td>
                                        <td>{customer.first}</td>
                                        <td>{customer.last}</td>
                                        <td>{customer.street}</td>
                                        <td>{customer.city}</td>
                                        <td>{customer.state}</td>
                                        <td>{customer.zip}</td>
                                        <td>{customer.phone}</td>
                                    </tr>
                                ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                <div className="list-row">
                    <button className="list-btn" type="button" onClick={edit} >Edit</button>
                </div>
            </div>
        </>
    )
}
