import { useState, useEffect, SetStateAction } from 'react';
import './App.css';
import { Customers, CustomerType } from './components/Customers'
import { CustomerEdit } from './components/CustomerEdit'

let initCustomer: CustomerType = {
  id: 0,
  first: '',
  last: '',
  street: '',
  city: '',
  state: '',
  zip: '',
  phone: ''
}

export type SetCustomerType = SetStateAction<CustomerType>
export type CustomersProps = { setCustomer: SetCustomerType }

export const App = () => {
  console.log('in App()')
  
  const [customer, setCustomer] = useState<CustomerType>(initCustomer);

  useEffect(() => {
    let url = "http://localhost:3000/customers"
    fetch(url)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not OK");
        }
        /*
        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            throw new TypeError("Error, response was not JSON!");
        }
        */
        return response.json();
      })
      .then((result) => {  // result is an object
        console.log("Success:", result);
        onSuccess.current(result);
      })
      .catch((error) => {
        console.error("There has been a problem with the fetch operation:", error);
      });
  }, [])



  return (
    <>
      <div>
        <Customers setCustomer={setCustomer} />
        <CustomerEdit customer={customer} />
      </div>
    </>
  )
}
